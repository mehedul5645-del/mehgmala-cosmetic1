-- Supabase SQL Editor-এ চালাও। এই স্কিমা প্রতিটি লগইন ব্যবহারকারীর নিজের state আলাদা রাখে।
create table if not exists public.shop_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  state jsonb not null default '{"products":[],"sales":[],"expenses":[],"cash":0,"debts":[],"audit":[]}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.shop_state enable row level security;
create policy "Users can read own shop state" on public.shop_state for select using (auth.uid() = user_id);
create policy "Users can insert own shop state" on public.shop_state for insert with check (auth.uid() = user_id);
create policy "Users can update own shop state" on public.shop_state for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
