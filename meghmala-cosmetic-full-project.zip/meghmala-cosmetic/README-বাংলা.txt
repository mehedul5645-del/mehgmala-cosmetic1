মেঘমালা কসমেটিক — পূর্ণাঙ্গ অ্যাপের প্রাথমিক প্রজেক্ট

এই ZIP-এ আছে:
- মোবাইল-উপযোগী ওয়েব অ্যাপ ও PWA manifest
- পণ্য/স্টক যোগ, সংশোধন ও মুছে ফেলা
- বারকোড ক্যামেরা স্ক্যানার (HTTPS/ক্যামেরা অনুমতি প্রয়োজন)
- ম্যানুয়াল পণ্য যোগ ও বিক্রয়মূল্য টাইপ/পরিবর্তন
- POS বিল, নগদ/বাকি প্রাথমিক রেকর্ড
- খরচ, ড্যাশবোর্ড, রিপোর্ট
- JSON ব্যাকআপ ও Restore
- Supabase Auth-এর প্রাথমিক লগইন ও ক্লাউড state sync কোড
- Supabase SQL schema

Netlify প্রকাশ:
1. ZIP Extract করে সব ফাইল GitHub repository-তে upload করো।
2. Netlify-তে Add new site > Import an existing project দিয়ে repository connect করো।
3. Build command: npm run build
4. Publish directory: dist
5. Supabase project তৈরি করে SQL Editor-এ supabase/schema.sql চালাও।
6. Netlify Site configuration > Environment variables-এ VITE_SUPABASE_URL এবং VITE_SUPABASE_ANON_KEY যোগ করো। .env.example-এ নমুনা আছে।
7. Deploy করো।

সীমাবদ্ধতা ও সতর্কতা:
- এই প্যাকেজটি সম্পূর্ণ পরীক্ষিত/প্রোডাকশন-রেডি হিসাব সফটওয়্যার নয়; প্রথমে test data দিয়ে পরীক্ষা করো।
- ক্লাউড sync কোড একটি user-এর state sync করে। একাধিক কর্মচারী, owner/staff role, shop-wide shared tenant, permission matrix, conflict-safe simultaneous updates, server-side scheduled backup এবং daily notifications এখনো সম্পূর্ণ বাস্তবায়িত নয়।
- customer mode-এ মূল্য/লাভ লুকানোর UI আছে, কিন্তু একই ডিভাইসে Admin/Customer আলাদা physical display বা নিরাপদ public display session নয়।
- বারকোড স্ক্যানারের জন্য HTTPS, ক্যামেরা permission ও সামঞ্জস্যপূর্ণ ব্রাউজার প্রয়োজন।
- অফলাইন queue ও conflict-free background sync এখনো নেই। localStorage-এ থাকা ডেটা browser data clear করলে হারাতে পারে। নিয়মিত JSON backup রাখো।
- লাভ/ক্ষতির নির্ভুল হিসাবের জন্য ক্রয়-ইনভয়েস, রিটার্ন, ছাড়, কর, stock adjustment ও expense classification আরও শক্তভাবে যাচাই/বাস্তবায়ন করতে হবে।
- Production ব্যবহারের আগে নিরাপত্তা পরীক্ষা, Supabase RLS review, backup restore test এবং হিসাব মিলিয়ে দেখা জরুরি।
